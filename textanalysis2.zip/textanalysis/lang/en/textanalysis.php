<?php 


$string['textanalysis'] = 'textanalysis';
$string['modulename'] = 'textanalysis';
$string['pluginname'] = 'textanalysis';
$string['modulenameplural'] = 'textanalysisS';
$string['intro'] = 'Intro';
$string['pluginadministration'] = 'textanalysis';
$string['config_textcompare'] = 'Text compare size (4-10)';
$string['config_textcompare_descr'] = '';
$string['config_textword'] = 'Text word size (0-3)';
$string['config_textword_descr'] = '';


?>
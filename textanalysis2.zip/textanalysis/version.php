<?php // $Id: mysql.php,v 1.0 2007/07/02 12:37:00 serafim panov

$module->version   = 2012030200;  
$module->cron      = 60;           
$module->requires  = 2011112900;  
$module->component = 'mod_textanalysis';


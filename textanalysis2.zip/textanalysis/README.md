********************************************************************************************* 
****** WARNING: THIS MODULE FOR MOODLE 2.2 ****** 
*********************************************************************************************

--------
ABOUT
--------
This is version 2.x of the "textanalysis" module (textanalysis).

2.x release is compatible only with Moodle 2.2.

The "textanalysis" module is developed by
    Serafim Panov, Paul Daniels.

This module may be distributed under the terms of the General Public License
(see http://www.gnu.org/licenses/gpl.txt for details)

-----------
PURPOSE
-----------
This module allows teachers to analyse students texts within site: forum, blog, chat and journal.

----------------
INSTALLATION
----------------
The textanalysis follows standard installation procedures.
Place the "textanalysis" directory in your mod directory.
Then visit the Admin page in Moodle to activate it.

